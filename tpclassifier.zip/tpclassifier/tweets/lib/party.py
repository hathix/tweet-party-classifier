class Party:
    Democrat = 0
    Republican = 1